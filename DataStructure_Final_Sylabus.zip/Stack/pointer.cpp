#include<iostream>
using namespace std;
int main()
{
	char *a,b;
	b = 'a';
	*a='\0';
	cout<<*a<<endl;
}
