#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}

		assign (float  y ) // constructor overloading
		{					  // parametrized constructor
			rs = y   ;
			ps = (y - rs) * 100   ;
		}
show  ()
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{

cash c1;
float y=12.11;
c1.assign(y);
c1.show();
}
