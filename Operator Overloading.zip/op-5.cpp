#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}

		assign (int a , int b )
		{
			rs = a ;
			ps = b ;
		}
	show  ()
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{

cash c1;
c1.assign(122,11);
c1.show();
}
