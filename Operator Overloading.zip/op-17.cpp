#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}
		cash (int a , int b ) // constructor overloading
		{					  // parametrized constructor
			rs = a ;
			ps = b ;
		}
		///////////////
		bool isgreater(cash c)
		{
        float first_amount  = rs   + float (ps) / 100 ;
			float second_amount = c.rs + float (ps) /100  ;
			if (first_amount > second_amount)
				return true ;
			else
				return false;
		}

		bool operator > (cash c)
		{
			float first_amount  = rs   + float (ps) / 100 ;
			float second_amount = c.rs + float (ps) /100  ;
			if (first_amount > second_amount)
				return true ;
			else
				return false;
		}
};
int main()
{

cash c1(122,1) ;
cash c2(11,1);
if(c1>c2==true)
cout<<"Onject 1 is greater.. .";
else
cout<<"Object 2 is greater....";
}
