#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}

		cash (float  y ) // constructor overloading
		{					  // parametrized constructor
			rs = y   ;
			ps = (y - rs) * 100   ;
		}
	show  ()
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{
	float y = 22.3;
cash c1(y);
c1.show();
}
