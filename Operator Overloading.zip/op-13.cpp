#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}
		cash (int a , int b ) // constructor overloading
		{					  // parametrized constructor
			rs = a ;
			ps = b ;
		}

			cash add2 (cash c1 )// first method of add
		{
			cash temp ;
			temp.rs = 	rs +  c1.rs   ;
			temp.ps =   ps +  c1.ps   ;
			return temp ;
		}
show  ()
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{

  cash c1(11,1);
cash c2(11,22);
cash c3;
c3 = c2.add2(c1);
c3.show();
}
