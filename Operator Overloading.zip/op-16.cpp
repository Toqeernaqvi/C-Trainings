#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}


		get  ()
		{
			cout <<"Enter rs " ; cin >> rs ;
			cout <<"Enter ps " ; cin >> ps ;
		}
		show  ()// first method display result
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
		void operator ++ ()//wnd method display result
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{

cash c1 ;
c1.get();
++ c1;
}
