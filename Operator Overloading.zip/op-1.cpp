#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}
	show  ()
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{
	cash c1;
	c1.show();
}
