#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}

		assign  (int x ) // fn overloading
		{
			rs = x / 100  ;
			ps = x % 100  ;
		}
show  ()
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{

cash c1;
c1.assign(12);
c1.show();
}
