#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}
		cash (int a , int b ) // constructor overloading
		{					  // parametrized constructor
			rs = a ;
			ps = b ;
		}

		 operator float ()
		{
			return (rs + float (ps) / 100 );

		}
};
int main()
{
cash c1(122,2);
  float x =c1;
 cout<<x;

}
