#include <iostream>
using namespace std;
class cash
{
	private:
		int rs , ps ;
	public:
		cash () // no argument constructor
		{
			rs = ps = 0 ;
		}
		cash (int a , int b ) // constructor overloading
		{					  // parametrized constructor
			rs = a ;
			ps = b ;
		}

		assign (cash  c1  ) // constructor overloading
		{					  // parametrized constructor
			rs = c1.rs   ;
			ps = c1.ps   ;
		}
show  ()
		{
			cout <<"Total  rs " <<  rs << endl ;
			cout <<"Total  ps " <<  ps << endl ;
		}
};
int main()
{

cash c1(122,2);
cash c2;
c2.assign(c1);

c2.show();
}
