#include <iostream>
using namespace std;
class parent
{
	private:
		void parent_private ()
		{
			cout <<"Parent Private" << endl ;
		}
	protected:
		void parent_protected ()
		{
			cout <<"Parent protected" << endl ;
		}
	public:
		void parent_public ()
		{
			cout <<"Parent public" << endl ;
		}
};
class child : public parent
{
	private:
		void child_private ()
		{
			cout <<"child Private" << endl ;
		}
	protected:
		void child_protected ()
		{
			cout <<"child protected" << endl ;
		}
	public:
		void child_public ()
		{
			cout <<"child public" << endl ;
			parent_public () ;//indirectly accecs to parent public().
		}
};
int main ( )
{
	parent p1 ;
	child  c1 ;

	c1.child_public () ;//indirectly acces to parent public().
	//c1.parent_public () ;


 		return 1 ;

}





