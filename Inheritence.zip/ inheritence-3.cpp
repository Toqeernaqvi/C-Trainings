#include<iostream>
using namespace std;

class A
{
	private :
		void Aprivate ()
		{
			cout << "APrivate"<<endl;
		}
	public  :
		void Apublic ()
		{
			cout << "APublic"<<endl;
		}
};
class B : public A
{
	private :
		void Bprivate ()
		{
			cout << "BPrivate"<<endl;
		}
	public  :
		void Bpublic ()
		{
			cout << "BPublic"<<endl;
			Bprivate (); // indirectly acces private
		}
};
int main()
{
B b ;
//b.Apublic () ;
b.Bpublic () ;	 //Class b object indirectly acces his private part .
// b.Aprivate() ; // not allowed
// b.Bprivate (); // not allowed

////////////////
//A a ;
//a.Apublic () ;
// a.Bpublic (); // not allowed
// a.Aprivate () ; // not allowed

}



