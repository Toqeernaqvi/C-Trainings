#include<iostream>
using namespace std;

class A
{
	private :
		void Aprivate ()
		{
			cout << "APrivate"<<endl;
		}
	public  :
		void Apublic ()
		{
			cout << "APublic"<<endl;
		}
};
class B : public A
{
	private :
		void Bprivate ()
		{
			cout << "BPrivate"<<endl;
			// Apublic  (); // allowd
			// Aprivate (); // not allowed
		}
	public  :
		void Bpublic ()
		{
			cout << "BPublic"<<endl;
			Aprivate  (); // not allowed indirectly acces parent private
		}
};
int main()
{
B b ;
//b.Apublic () ;
b.Bpublic () ;//Error because not allowed indirectly acces parent private.
// b.Aprivate() ; // not allowed
// b.Bprivate (); // not allowed

////////////////
//A a ;
//a.Apublic () ;
// a.Bpublic (); // not allowed
// a.Aprivate () ; // not allowed

}



