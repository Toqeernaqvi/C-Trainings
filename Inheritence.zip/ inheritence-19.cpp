#include <iostream>
using namespace std;
class parent
{
	private:
		void parent_private ()
		{
			cout <<"Parent Private" << endl ;
		}
	protected:
		void parent_protected ()
		{
			cout <<"Parent protected" << endl ;
		}
	public:
		parent ()	//constructor
		{
			cout << "Parent Constructor " << endl ;
		}
		~parent ()	//destructor
		{
			cout << "Parent Destructor " << endl ;
		}
		void parent_public ()
		{
			cout <<"Parent public" << endl ;
		}
};
class child : public parent
{
	private:
		void child_private ()
		{
			cout <<"child Private" << endl ;
		}
	protected:
		void child_protected ()
		{
			cout <<"child protected" << endl ;
		}
	public:
		child ()	//constructor
		{
			cout << "child Constructor " << endl ;
		}
		~child ()	//destructor
		{
			cout << "child Destructor " << endl ;
		}
		void child_public ()
		{
			cout <<"child public" << endl ;
			child_private () ;
		}
};
int main ( )
{
	parent p1 ;//only Execute parent class Constructor and Destructor
	//child  c1 ;



 		return 1 ;

}





