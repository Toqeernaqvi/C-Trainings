#include<iostream>
using namespace std;

class A
{
	private :
		void Aprivate ()
		{
			cout << "APrivate"<<endl;
		}
	public  :
		 A () { cout << "Constructor of class A" << endl ;		}//Constructor
		~A () { cout << "Destructor  of class A" << endl ;		}//Destructor
		void Apublic ()
		{
			cout << "APublic"<<endl;
		}

};
class B : public A
{
	private :
		void Bprivate ()
		{
			cout << "BPrivate"<<endl;
		}
		public  :
		B  () { cout << "Constructor of class B" << endl ;		}//Constructor
		~B () { cout << "Destructor  of class B" << endl ;		}//Destructor
		void Bpublic ()
		{
			cout << "BPublic"<<endl;
		}
};
int main()
{

A a ;// Execute Constructor and Destructor of A class.

//B b ;
//b.Apublic () ;
/*	A a ;
	a.Apublic  ();
//	a.Aprivate ();   not allowed
//	a.Aprotected (); not allowed

	B b ;
	b.Bpublic  () ;
//	b.Bprivate ();  not allowed ;
	b.Apublic()   ;
//	b.Aprivate()  ; not allowed
//	b.Aprotected () ; not allowed
*/
 /*A a ;
 a.Apublic ();
 */
/*
 //A a ;
 B  b ;
 */

}




