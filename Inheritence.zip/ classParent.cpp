#include <iostream>
using namespace std;
class parent
{
		public:
		parent ()//constructor
		{
			cout << "Parent Constructor " << endl ;
		}
		parent (int x )//parameterized constructor
		{
			cout << "Parent Constructor " << x <<  endl ;
		}
};

int main ( )
{
	parent p1 , p2 (420) ;	// passing argument to constructor




 		return 1 ;

}