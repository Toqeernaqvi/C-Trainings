#include<iostream>
using namespace std;

class A
{
	private 	:
	protected 	:
	public  	:
			void disp ()
			{
				cout << "display function  " <<endl ;
			}
			void operator ++ ()// operator overloading function
			{
				cout << "operator over load function ++" <<endl ;
			}
			void operator -- ()//operator overloading function
			{
				cout << "operator over load function -- "<<endl ;
			}

};

int main()
{
	A a 	; //a.disp();
	++ a  	;//call operator overloading function of class A..
	--a;//call operator overloadin function of class A
}
/*
distance d1 , d2, d3 ;
d3 = d1.add (d2);
d3= d1+ d2 ;

cash c1.c2,c3;
c3=c2-c1;
*/

