#include <iostream>
using namespace std;
class parent
{
	private:
		void parent_private ()
		{
			cout <<"Parent Private" << endl ;
		}
	protected:
		void parent_protected ()
		{
			cout <<"Parent protected" << endl ;
		}
	public:
		parent ()
		{
			cout << "Parent Constructor " << endl ;
		}
		void parent_public ()
		{
			cout <<"Parent public" << endl ;
		}
};
class child : public parent
{
	private:
		void child_private ()
		{
			cout <<"child Private" << endl ;
		}
	protected:
		void child_protected ()
		{
			cout <<"child protected" << endl ;
		}
	public:
		child ()
		{
			cout << "child Constructor " << endl ;
		}
		void child_public ()
		{
			cout <<"child public" << endl ;
			child_private () ;//indirectly acces to child private
		}
};
int main ( )
{
	//parent p1 ;
	child  c1 ;



 		return 1 ;

}





