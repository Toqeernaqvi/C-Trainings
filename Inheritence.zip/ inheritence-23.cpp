#include<iostream>
using namespace std;

class A
{
	private :
		void Aprivate ()
		{
			cout << "APrivate"<<endl;
		}
	protected :
		void Aprotected ()
		{
			cout << "Aprotected"<<endl;
		}
	public  :
		 A () { cout << "Constructor of class A" << endl ;		}
		~A () { cout << "Destructor  of class A" << endl ;		}
		void Apublic ()
		{
			cout << "APublic"<<endl;
		}

};
class B : public A
{
	private :
		void Bprivate ()
		{
			cout << "BPrivate"<<endl;
		}
	protected :
		void Bprotected ()
		{
			cout << "Bprotected"<<endl;
		}
	public  :
		B  () { cout << "Constructor of class B" << endl ;		}
		~B () { cout << "Destructor  of class B" << endl ;		}
		void Bpublic ()
		{
			cout << "BPublic"<<endl;
			//Bprivate   () ;
			//Bprotected () ;
			//Apublic    () ;
			//Aprotected () ;
		//	Aprivate   () ; not allowed
		}
		void Apublic ()//Method overloading of parent class A
		{
			cout << "Apublic in class B"<< endl  ;
		}
};
int main()
{
B b ;
b.Apublic () ;	//Class B object acces his overloading function of parent class A
/*	A a ;
	a.Apublic  ();
//	a.Aprivate ();   not allowed
//	a.Aprotected (); not allowed

	B b ;
	b.Bpublic  () ;
//	b.Bprivate ();  not allowed ;
	b.Apublic()   ;
//	b.Aprivate()  ; not allowed
//	b.Aprotected () ; not allowed
*/
 /*A a ;
 a.Apublic ();
 */
/*
 //A a ;
 B  b ;
 */

}




