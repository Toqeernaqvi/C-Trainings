#include<iostream>
using namespace std;

class A
{
	private :
	public  :
		void Apublic ()
		{
			cout << "APublic"<<endl;
		}
};
class B : public A
{
	private :
	public  :
		void Bpublic ()
		{
			cout << "BPublic"<<endl;
		}
};
int main()
{
B b ;
b.Apublic () ;	//class B object acces parent class A public().
b.Bpublic ()  ;	//class B object acces his  public part().

A a ;
a.Apublic () ;//class A object acces his  public part().
// a.Bpublic (); // not allowed

}



