#include<iostream>
using namespace std;

class A
{
	private :
		void Aprivate ()
		{
			cout << "APrivate"<<endl;
		}
	public  :
		void Apublic ()
		{
			cout << "APublic"<<endl;
		}
};
class B : public A
{
	private :
		void Bprivate ()
		{
			cout << "BPrivate"<<endl;
		}
	public  :
		void Bpublic ()
		{
			cout << "BPublic"<<endl;
		}
};
int main()
{
B b ;
b.Apublic () ;	//Class B object acces class A public
b.Bpublic () ;	//Class B object acces class B public
// b.Aprivate() ; // not allowed
// b.Bprivate (); // not allowed
A a ;
a.Apublic () ;//Class A object acces his publc part.
// a.Bpublic (); // not allowed
// a.Aprivate () ; // not allowed

}



