#include<iostream>
using namespace std;
class A
{
	private :
		void Aprivate ()
		{
			cout << "APrivate"<<endl;
		}
	protected :
		void Aprotected ()
		{
			cout << "Aprotected"<<endl;
		}
	public  :
		void Apublic ()
		{
			cout << "APublic"<<endl;
		}
};
class B : public A
{
	private :
		void Bprivate ()
		{
			cout << "BPrivate"<<endl;
		}
	protected :
		void Bprotected ()
		{
			cout << "Bprotected"<<endl;
		}
	public  :
		void Bpublic ()
		{
			cout << "BPublic"<<endl;
			Bprivate   () ;
			Bprotected () ;
			Apublic    () ;
			Aprotected () ;
		//	Aprivate   () ; not allowed
		}
};
int main()
{
B b ;
//b.Apublic    () ;
b.Bpublic    () ;// B Class object Acces B private , B protected ,A public() and A protected
//b.Bprivate   () ;    not allowed
// b.Bprotected () ;	not allowed
/*	A a ;
	a.Apublic  ();
//	a.Aprivate ();   not allowed
//	a.Aprotected (); not allowed

	B b ;
	b.Bpublic  () ;
//	b.Bprivate ();  not allowed ;
	b.Apublic()   ;
//	b.Aprivate()  ; not allowed
//	b.Aprotected () ; not allowed
*/
 /*A a ;
 a.Apublic ();
 */
/*
 //A a ;
 B  b ;
 */

}




