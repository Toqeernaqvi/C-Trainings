#include<iostream>
using namespace std;
class parent{
public:
  virtual void show()
  {
    cout<<"PArent Class...."<<endl;
    }
};
class child:public parent
{
	public:
		void show()
		{
			cout<<"Child class.."<<endl;
		}

};
int main()
{
    parent *ptr;
	child c1;

	 ptr=&c1;
	ptr->show();

}
////////////////
//1  pointer of parent class  can acces child class attributes and members;

