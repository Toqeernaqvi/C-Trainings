/*
Late Binding
Compiler doesn't know until runtime which function to invoke.

In some programs, it's not possible to know which function will be called until runtime.
This is known as late binding (or dynamic binding).
 In C++, one way to get late binding is to use function pointers
 or the other way is the use of virtual functions in inheritance. e.g.,
*/
#include<iostream>
using namespace std;
/////////////////////////////////////
int add(int x, int y)
{
return x + y;
}
///////////////////////////////////
int subtract(int x, int y)
 {
 return x - y;
 }
 /////////////////////////////////////

 int main()
 {
  int x, y;
  cout<<"Enter two numbers : ";
 cin >> x >> y;
 int operation;
 cout << "choose 0 for add & 1 for subtract\n";
 cin >> operation;
 int (*p)(int, int);  // Function Pointer     // Set p to point to the function the user chose
 switch (operation)
 {
  case 0 :
  p = add;
   break;
   case 1 :
   p = subtract;
  break;
 }     // Call the function that p is pointing to    std::
 cout << "The answer is: " << p(x, y) << std::endl;
     return 0;
     }

