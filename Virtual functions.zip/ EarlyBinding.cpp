/*
Early Binding
Compiler knows at compile time which function to invoke.

Most of the function calls the compiler encounters will be direct function calls. e.g.,
*/
#include<iostream>
using namespace std;
int sum(int a, int b)
{
return a + b;
}
///////////
int main()
{
cout << sum(2, 3); // This is a direct function call
return 0;

}
/*
Direct function calls can be resolved using a
 process known as early binding.
 Early binding (also called static binding) means
  the compiler is able to directly associate
 the identifier name (such as a function or variable name)
  with a machine address.
 Remember that all functions have a unique machine address.
 So when the compiler encounters a function call,
  it replaces the function call with a machine language
   instruction that tells the CPU to jump to the address of the function.
   */
